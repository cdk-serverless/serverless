let lessc = require('./src/compilers/less/lessCompiler')({ cacheEnabled: false });

exports.handler = async (input) => {
    let result = await lessc.compile(input.source, input.variables, input.modules, input.name, true);
    return result;
}
