const CacheAgent = module.exports = {};

const NodeCache = require("node-cache");

const store = new NodeCache( { stdTTL: 7 * 24 * 60 * 60, checkperiod:  1 * 24 * 60 * 60} );

CacheAgent.get = (type, key) => {

    let path = pathFor(type, key);

    return store.get(path);
};

CacheAgent.put = (type, key, value) => {

    let path = pathFor(type, key);

    store.set(path, value);

    return value;
};

CacheAgent.delete = (type, key) => {

    let path = pathFor(type, key);

    store.del(path);

};


CacheAgent.getAll = () => {
    var result = {};
    var keys = store.keys()
    keys.forEach(function (key) {
        result[key] = store.get(key);
    });
    return result;
};

CacheAgent.purge = () => {
    store.flushAll();
};


const pathFor = (type, key) => {
    return `${type}:${key}`;
};
