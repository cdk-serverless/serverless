let cache;

let assert = require('assert');

beforeEach(async function() {
    cache = require('../../local');
});

describe("Local Cache Agent", function() {


    it("puts object into cache", () => {
        let obj = {
            person1: "santa",
            person2: "banta"
        };

        cache.put("person", "nicePersons", obj);
        let cachedObj = cache.get("person", "nicePersons");
        assert.equal(cachedObj, obj)
    });

    it("deletes object from cache", function () {
        let obj = {
            person1: "santa",
            person2: "banta"
        };

        cache.put("person", "nicePersons", obj);

        let cachedObj = cache.get("person", "nicePersons");
        assert.equal(cachedObj, obj);

        cache.delete("person", "nicePersons");
        cachedObj = cache.get("person", "nicePersons");
        assert.equal(cachedObj, undefined)

    });


    it("gets all objects from cache", () => {
        let obj = {
            person1: "santa",
            person2: "banta"
        };
        let obj2 = {
            person1: "santa",
            person2: "banta"
        }

        cache.put("person", "nicePersons", obj);
        cache.put("people", "nicePersons", obj2);
        let cachedObj = cache.getAll();

        assert.equal(Object.keys(cachedObj).length, 2)
    });

    it("deletes  all object from cache", function () {
        let obj = {
            person1: "santa",
            person2: "banta"
        };
        let obj2 = {
            person1: "santa",
            person2: "banta"
        }

        cache.put("person", "nicePersons", obj);
        cache.put("people", "nicePersons", obj2);

        let cachedObj = cache.get("person", "nicePersons");
        assert.equal(cachedObj, obj);

        cache.purge();
        cachedObj = cache.get("person", "nicePersons");
        assert.equal(cachedObj, undefined)
        cachedObj = cache.get("people", "nicePersons");
        assert.equal(cachedObj, undefined)

    });

});