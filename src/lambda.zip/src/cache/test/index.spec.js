
let cacheFactory, remote, local;
let proxyquire = require('proxyquire').noCallThru();
let assert = require('assert');

beforeEach(() => {

    remote = {
        name: "remote"
    };

    local = {
        name: "local"
    };

    cacheFactory = proxyquire('../../../lib/cache', {
        './remote': remote,
        './local': local
    });
});

describe("Cache Factory", function() {

    it("returns remote cache", () => {
        let cache = cacheFactory.get("remote");
        assert.equal(cache, remote)
    });


    it("return local cache", () => {
        let cache = cacheFactory.get();
        assert.equal(cache, local)
    });

});