const CacheFactory = module.exports = {};
const localCache = require("./local");

CacheFactory.get = (type) => {
    let cache = localCache;
    return cache;
};