(function(){
    "use strict";

    const chroma = require('chroma-js');
    const _SHADES = [0, 50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];

    function Luminosity (){

    }

    /**
     * @param {object} settings
     * @returns {string} of LESS
     */

    let calculate = module.exports.calculate = (settings) => {

        var newLESS = "";

        settings = getValidSettings(settings);

        settings.forEach(function addColorsFrom (setting) {
            newLESS += ("\n" + generateColorsFor(setting));
        });

        return newLESS;
    };


    /**
     * Find all immediate properties of argument that are a CSS color. Return the found set as
     * an array of objects in the format used by the color generation function here.
     * @param {object} settings
     * @returns {Array}
     */

    let getValidSettings = (settings) => {

        let valids = [];

        if (settings && typeof settings === 'object') {
            Object.keys(settings).forEach(function pushIfGood (key) {
                var val = settings[key];
                if (typeof val === 'string' && isCssColor(val)) {
                    valids.push({key: key, value: val});
                }
            });
        }

        return valids;
    };


    /**
     * @param {string} val
     * @throws if arg is not a string
     * @returns {boolean}
     */
    let isCssColor = (val) => {
        val = val.toLocaleLowerCase().replace(" ", "");
        var isCssColorName = !!chroma.colors[val];
        var isHex = isHexColor(val);
        var isRgb = isRgbColor(val);
        var isRgba = isRgbaColor(val);
        var isHsl  = isHslColor(val);
        var isHsla = isHslaColor(val);
        return isCssColorName || isHex || isRgb || isRgba || isHsl || isHsla;
    };

    // Regular expressions source: https://gist.github.com/sethlopezme/d072b945969a3cc2cc11
    function isHexColor (val) {
        var regex = /^#?([a-f\d]{3}|[a-f\d]{6})$/;
        return regex.test(val);
    }

    function isRgbColor (val) {
        var regex = /^rgb\((0|255|25[0-4]|2[0-4]\d|1\d\d|0?\d?\d),(0|255|25[0-4]|2[0-4]\d|1\d\d|0?\d?\d),(0|255|25[0-4]|2[0-4]\d|1\d\d|0?\d?\d)\)$/;
        return regex.test(val);
    }

    function isRgbaColor (val) {
        var regex = /^rgba\((0|255|25[0-4]|2[0-4]\d|1\d\d|0?\d?\d),(0|255|25[0-4]|2[0-4]\d|1\d\d|0?\d?\d),(0|255|25[0-4]|2[0-4]\d|1\d\d|0?\d?\d),(0?\.\d|1(\.0)?)\)$/;
        return regex.test(val);
    }

    function isHslColor (val) {
        var regex = /^hsl\((0|360|35\d|3[0-4]\d|[12]\d\d|0?\d?\d),(0|100|\d{1,2})%,(0|100|\d{1,2})%\)$/;
        return regex.test(val);
    }

    function isHslaColor (val) {
        var regex = /^hsla\((0|360|35\d|3[0-4]\d|[12]\d\d|0?\d?\d),(0|100|\d{1,2})%,(0|100|\d{1,2})%,(0?\.\d|1(\.0)?)\)$/;
        return regex.test(val);
    }


    /**
     * @param {object} setting - presumed structure is {key: stringName, value: cssColor}
     * @returns {string} of LESS
     */
    function generateColorsFor (setting) {

        var output = "";

        // Make sure key (which will be LESS variable name) starts with "@":
        var key = setting.key.indexOf("@")===0 ? setting.key : "@"+setting.key;

        _SHADES.forEach((shadeValue) => {
            var calcVal = shade(setting.value, shadeValue);
            var calcKey = key + shadeValue;
            var colorSetting = lessVarStatement(calcKey, calcVal);
            var textColor = contrastColorFor(calcVal);
            var textColorSetting = lessVarStatement(calcKey + "-text", textColor);
            output += (colorSetting + textColorSetting);
        });

        var initialSettingOutput = "\n" + key + ": " + setting.value + ";"; // e.g. (newline)@accent: #444;

        return output + initialSettingOutput;
    }


    function lessVarStatement (key, value){
        return key + ": " + value + ";\n";
    }

    /**
     * Given a color value, return either black or white, whichever has better contrast > 4.5, per
     * W3C guidelines, http://www.w3.org/TR/WCAG20-TECHS/G18.html
     *
     * @param {string} bgColor
     * @returns {string} color value
     */

    function contrastColorFor (bgColor) {
        return chroma.contrast("#000", bgColor) > 4.5 ? "#000" : "#fff";
    }


    let shade = (baseColor, luminosity) => {

        var colorCurve,
            scale,
            adjustedColor;

        // Create a gradient curve  that ranges from white to black, moving through the base color.
        // We want this gradient to bias toward the base color, which is why we add it multiple times:
        colorCurve = chroma.bezier(["white", baseColor, baseColor, baseColor, "black"]);

        // Using the LAB color space, create a scale that is luminosity corrected:
        scale = chroma.scale(colorCurve).mode("lab").domain([0, 1000]);

        // Finally, get the shade for the given luminosity:
        adjustedColor = scale(luminosity).hex();

        return adjustedColor;
    };

}());
