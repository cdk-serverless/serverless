const request = require("superagent");
const less = require('less');
const luminosity = require("./luminosity");
const LessPluginAutoPrefix = require("less-plugin-autoprefix");
const lessGlobalPlugin = require("less-plugin-glob");
const LessContrastRatio = require("less-plugin-contrast-ratio");
const hlp = require("hydra-less-plugins");
const cache = require("../../cache");
const localCache = cache.get();
const path = require("path");

const SUPPORTED_BROWSERS = [
    "Chrome >= 47",
    "Firefox >= 43",
    "Explorer >= 11",
    "Edge >= 25",
    "iOS >= 7",
    "Safari >= 7",
    "ExplorerMobile >= 11",
    "Android >= 30"];
let errorMaskSuffix = "';} body > * {display: none;}";
let startFile = "";

const init = (opts = {}) => {
    const Compiler = {
        cacheEnabled: opts.cacheEnabled || false,
        /**
         * @param lessURL {string} = pass less url
         * @param basePath {string} = base path for imports
         * @param variables {object} = less variable needed to be compiled with
         *
         **/
        compile(lessURL, variables, modules, name, useCache) {
            return Promise.resolve(true).then(function () {
                return requestP(lessURL);
            }).then(function (response) {
                let lessContent = response.text;
                if (lessContent) {
                    let custom = (luminosity.calculate(variables)) + (translateSettingsToLess(variables) || "");
                    lessContent += custom;
                    let match = lessURL.match(/([^/][\d\w\.less]+)$/);
                    startFile = match ? match[0] : "Input";
                    let lastIndex = lessURL.lastIndexOf("/");
                    let basePath = lessURL.substring(0, lastIndex + 1);
                    return compileLess(lessContent, {
                        source: basePath,
                        modules: modules,
                        useCache: useCache,
                        name: name
                    });
                } else {
                    return "";
                }
            });
        }
    };


    /**
     * @param {string} rawCSS
     * @param {object} opts
     * @returns {*|promise}
     */
    let compileLess = (rawCSS, opts) => {

        //TODO: enable autoprefix based on the flag
        opts = opts || {};
        let modulesMap = opts.modules;

        let getSource = (name) => {
            let designAssetUrl;

            if(modulesMap["designsPath"]){
                designAssetUrl =  modulesMap['designsPath'] + "/designs/" + name;
            } else if (modulesMap && modulesMap[name] && typeof  modulesMap[name] == "string") {
                designAssetUrl =  modulesMap[name];
            }

            return designAssetUrl.slice(-1) === '/' ? designAssetUrl : designAssetUrl + "/";
        };

        let useCache = Compiler.cacheEnabled;

        let urlFileManagerOpts = {
            basePath: opts.source,
            designName: opts.name,
            getSource: getSource

        };
        let npmUrlFileManagerOpts = {
            source: opts.source,
            getSource: getSource
        };
        if(opts.useCache == "true"){
            useCache = "true";
        }

        var urlFileManager, npmUrlFileManager ;
        if(useCache){
            urlFileManager = new hlp.UrlFileManagerWithCache(urlFileManagerOpts, localCache);
            npmUrlFileManager = new hlp.NpmUrlFileManagerWithCache(npmUrlFileManagerOpts, localCache);

        }else{
            urlFileManager = new hlp.UrlFileManager(urlFileManagerOpts);
            npmUrlFileManager = new hlp.NpmUrlFileManager(npmUrlFileManagerOpts);
        }


        let autoprefixerConfig = {
            remove: false,
            browsers: SUPPORTED_BROWSERS
        };

        let options = {
            filename: startFile,
            plugins: [
                lessGlobalPlugin,
                hlp.directiveParser,
                hlp.directiveEncoder,
                hlp.directiveInitiator,
                urlFileManager,
                npmUrlFileManager,
                (new LessPluginAutoPrefix(autoprefixerConfig)),
                (new LessContrastRatio())
            ]

        };
        return less.render(rawCSS, options).then(function (output) {
            return output && output.css ? output.css : output;
        }).catch((err) => {
            var fileLocator = err.filename;
            var lineNumber = err.line || '';
            var errDetails = fileLocator + ":" + lineNumber + " -> " + err.message;

            console.error(err);

            throw new Error("body:after {content: '" + errDetails + errorMaskSuffix);
        });
    };

    /**
     * @settings {object}
     * @returns {string}
     *
     * */

    let translateSettingsToLess = (settings) => {

        var translation = "";

        settings = typeof settings === 'object' ? settings : {};

        Object.getOwnPropertyNames(settings).forEach(function translate(prop) {
            var settingAsLESS = "",
                value = settings[prop];

            // Only append if value is valid string.
            var type = typeof value;
            if ((type === "string" || type === "boolean") && value !== "") {
                prop = prop.indexOf("@") === 0 ? prop : "@" + prop;// append "@" only if needed
                if(type === "string" && value.indexOf("http") === 0){
                    value = `'${value}'`;
                }
                settingAsLESS = "\n" + prop + ": " + value + ";";// e.g. "@a: b;"
            }

            translation += settingAsLESS;
        });

        return translation;
    };

    let requestP = (url) => {
        return new Promise(function (resolve, reject) {

            let serviceCall = request.get(url);
            if(global.process.domain && global.process.domain.reqCache && global.process.domain.reqCache['Logging-CorrelationId']){
                serviceCall.set('Logging-CorrelationId', global.process.domain.reqCache['Logging-CorrelationId']);
            }
            serviceCall.set('User-Agent', 'Hydra-Style-Server');

            serviceCall.end(function(err, res){
                if (err && (!res || res.statusCode != 404)) {
                    reject(err);
                }
                resolve(res);
            })

        });
    };
    return Compiler;
};


module.exports = init;

